package com.example.musicinstructionapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PlaySongActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_play);

        Intent intent = getIntent();

        //set intent data to proper text Boxes

        String trackNameInfo = intent.getStringExtra("trackName");
        TextView trackNameTB = (TextView) findViewById(R.id.trackName);
        trackNameTB.setText(trackNameInfo);

        String albumNameInfo = intent.getStringExtra("albumName");
        TextView albumNameTB = (TextView) findViewById(R.id.albumName);
        albumNameTB.setText(albumNameInfo);

        String singerNameInfo = intent.getStringExtra("singerName");
        TextView singerNameTB = (TextView) findViewById(R.id.singerName);
        singerNameTB.setText(singerNameInfo);

        //play button
        Button Play_button = (Button) findViewById(R.id.btn_button);
        Play_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(v.getContext(), "enjoy your track ", Toast.LENGTH_SHORT).show();

            }


        });

        //back button
        Button back_button=(Button)findViewById(R.id.btn_Back);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent=new Intent(PlaySongActivity.this,MainActivity.class);
                startActivity(backIntent);
            }
        });


    }
}
