package com.example.musicinstructionapp;

public class TrackInfo {
    String mTrackName;
    String mAlbumName;
    String mSinger;

    public TrackInfo(String mTrackName, String mAlbumName, String mSinger) {
        this.mTrackName = mTrackName;
        this.mAlbumName = mAlbumName;
        this.mSinger = mSinger;
    }

    public String getmTrackName() {
        return mTrackName;
    }

    public void setmTrackName(String mTrackName) {
        this.mTrackName = mTrackName;
    }

    public String getmAlbumName() {
        return mAlbumName;
    }

    public void setmAlbumName(String mAlbumName) {
        this.mAlbumName = mAlbumName;
    }

    public String getmSinger() {
        return mSinger;
    }

    public void setmSinger(String mSinger) {
        this.mSinger = mSinger;
    }
}
