package com.example.musicinstructionapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ArrayList<TrackInfo> trackList = new ArrayList<>();
        trackList.add(new TrackInfo("track1", "AlbumA", "singerA"));
        trackList.add(new TrackInfo("track2", "AlbumA", "singerA"));
        trackList.add(new TrackInfo("track3", "AlbumA", "singerA"));
        trackList.add(new TrackInfo("track1", "AlbumB", "singerB"));
        trackList.add(new TrackInfo("track2", "AlbumB", "singerB"));
        trackList.add(new TrackInfo("track3", "AlbumB", "singerB"));
        trackList.add(new TrackInfo("track4", "AlbumB", "singerB"));
        trackList.add(new TrackInfo("track1", "AlbumB", "singerC"));
        trackList.add(new TrackInfo("track2", "AlbumB", "singerC"));
        trackList.add(new TrackInfo("track3", "AlbumB", "singerC"));
        trackList.add(new TrackInfo("track4", "AlbumB", "singerC"));
        trackList.add(new TrackInfo("track1", "AlbumB", "singerD"));
        trackList.add(new TrackInfo("track2", "AlbumB", "singerD"));
        trackList.add(new TrackInfo("track3", "AlbumB", "singerD"));
        trackList.add(new TrackInfo("track4", "AlbumB", "singerD"));

        SongAdapter adapter = new SongAdapter(this, trackList);

        ListView listView = (ListView) findViewById(R.id.main_list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//              catch clicked data
                TrackInfo curentItem = (TrackInfo) parent.getItemAtPosition(position);
//              create intent to transfer new page
                Intent intent = new Intent(MainActivity.this, PlaySongActivity.class);
//              set selected Item data to intent
                intent.putExtra("trackName", curentItem.getmTrackName().toString());
                intent.putExtra("albumName", curentItem.getmAlbumName().toString());
                intent.putExtra("singerName", curentItem.getmSinger().toString());
                startActivity(intent);
            }
            Button listViewBtn =(Button)findViewById(R.id.btn_ListView);




        });


    }
}




