package com.example.musicinstructionapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ArrayList<TrackInfo> trackList = new ArrayList<>();
        trackList.add(new TrackInfo("track1", "AlbumA", "singerA"));
        trackList.add(new TrackInfo("track2", "AlbumA", "singerA"));
        trackList.add(new TrackInfo("track3", "AlbumA", "singerA"));
        trackList.add(new TrackInfo("track1", "AlbumB", "singerB"));
        trackList.add(new TrackInfo("track2", "AlbumB", "singerB"));
        trackList.add(new TrackInfo("track3", "AlbumB", "singerB"));
        trackList.add(new TrackInfo("track4", "AlbumB", "singerB"));
        trackList.add(new TrackInfo("track1", "AlbumB", "singerC"));
        trackList.add(new TrackInfo("track2", "AlbumB", "singerC"));
        trackList.add(new TrackInfo("track3", "AlbumB", "singerC"));
        trackList.add(new TrackInfo("track4", "AlbumB", "singerC"));
        trackList.add(new TrackInfo("track1", "AlbumB", "singerD"));
        trackList.add(new TrackInfo("track2", "AlbumB", "singerD"));
        trackList.add(new TrackInfo("track3", "AlbumB", "singerD"));
        trackList.add(new TrackInfo("track4", "AlbumB", "singerD"));

        SongAdapter adapter = new SongAdapter(this, trackList);

        ListView listView = (ListView) findViewById(R.id.main_list);
        listView.setAdapter(adapter);


//        listView.setOnItemClickListener (new AdapterView.OnItemClickListener () {
//
//            @Override
//
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//                Intent playIntent = new Intent (MainActivity.this, PlaySongActivity.class);
//
//                startActivity (playIntent); }
//
//        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, PlaySongActivity.class);
                TrackInfo curentItem = (TrackInfo) parent.getItemAtPosition(position);
                final String trackName = curentItem.getmTrackName();
                final String albumName = curentItem.getmTrackName();
                final String singerName = curentItem.getmSinger();
                intent.putExtra("trackName", trackName);
                intent.putExtra("albumName", albumName);
                intent.putExtra("singerName", singerName);
            }
        });
    }}









//    public void OpenSongClickListener(View view) {
//        Intent intent=new Intent(this, PlaySongActivity.class);
//        TrackInfo selectedTrack =
//        intent.putExtras()
//              startActivity(intent);
//    }
//    SongClickListener songClickListener=new SongClickListener();
//    ListView listView = (View)findViewById(R.id.main_list);
//    listView.


