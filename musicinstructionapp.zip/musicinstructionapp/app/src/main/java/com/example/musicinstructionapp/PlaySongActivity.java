package com.example.musicinstructionapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class PlaySongActivity extends AppCompatActivity {
Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_play);
//        intent=getIntent();
//
//        TextView albumTextView= (TextView)findViewById(R.id.album);

//        String albumNameValue =intent.getStringExtra("albumName");
//        albumTextView.setText(albumNameValue);
//        albumTextView.setText(trackName);
    }


}
