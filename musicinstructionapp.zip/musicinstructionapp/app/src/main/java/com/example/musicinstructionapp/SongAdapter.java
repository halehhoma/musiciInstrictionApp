package com.example.musicinstructionapp;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.musicinstructionapp.R;

import java.util.ArrayList;
import java.util.List;

public class SongAdapter extends ArrayAdapter<TrackInfo>  {



    String mTrack;
    String mAlbum;
    String mArtist;




    public SongAdapter(Activity context, ArrayList<TrackInfo> trackInfoArrayList) {
        super(context, 0, trackInfoArrayList);

    }

    public String getmTrack() {
        return mTrack;
    }

    public void setmTrack(String mTrack) {
        this.mTrack = mTrack;
    }

    public String getmAlbum() {
        return mAlbum;
    }

    public void setmAlbum(String mAlbum) {
        this.mAlbum = mAlbum;
    }

    public String getmArtist() {
        return mArtist;
    }

    public void setmArtist(String mArtist) {
        this.mArtist = mArtist;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if the existing view is being reused, otherwise inflate the view
    /*    View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.song_layout, parent, false);*/

        // Get the {@link AndroidFlavor} object located at this position in the list
        TrackInfo currentSong = getItem(position);
        View listItemView=convertView;
        if(listItemView==null)
        { listItemView=LayoutInflater.from(getContext()).inflate(
                R.layout.song_layout, parent, false);
        }

//convertView.setOnClickListener();
//        listItemView.setOnClickListener( );

        TextView singerTextView = (TextView) listItemView.findViewById(R.id.singer);
        singerTextView.setText(currentSong.getmSinger());

        TextView trackTextBox = (TextView) listItemView.findViewById(R.id.trackName);
        trackTextBox.setText(currentSong.mTrackName);

        TextView AlbumTextView = (TextView) listItemView.findViewById(R.id.album);
        AlbumTextView.setText(currentSong.getmAlbumName());


        return listItemView;
    }
}
