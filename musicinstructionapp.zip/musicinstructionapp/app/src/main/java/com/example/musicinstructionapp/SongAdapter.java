package com.example.musicinstructionapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.musicinstructionapp.R;

import java.util.ArrayList;
import java.util.List;

public class SongAdapter extends ArrayAdapter<TrackInfo>  {



    String mTrack;
    String mAlbum;
    String mArtist;



 //constructor which inherited from parent (Array Adapter)
    public SongAdapter(Activity context, ArrayList<TrackInfo> trackInfoArrayList) {
        super(context, 0, trackInfoArrayList);

    }

    public String getmTrack() {
        return mTrack;
    }

    public void setmTrack(String mTrack) {
        this.mTrack = mTrack;
    }

    public String getmAlbum() {
        return mAlbum;
    }

    public void setmAlbum(String mAlbum) {
        this.mAlbum = mAlbum;
    }

    public String getmArtist() {
        return mArtist;
    }

    public void setmArtist(String mArtist) {
        this.mArtist = mArtist;
    }


    @Override
    public View getView(int position, final View convertView, final ViewGroup parent) {

        TrackInfo currentSong = getItem(position);
        View listItemView=convertView;
        if(listItemView==null)
        { listItemView=LayoutInflater.from(getContext()).inflate(
                R.layout.song_layout, parent, false);
        }
        //set dara in proper position in listView

        TextView singerTextView = (TextView) listItemView.findViewById(R.id.singer);
        singerTextView.setText(currentSong.getmSinger());

        TextView trackTextBox = (TextView) listItemView.findViewById(R.id.trackName);
        trackTextBox.setText(currentSong.mTrackName);

        TextView AlbumTextView = (TextView) listItemView.findViewById(R.id.album);
        AlbumTextView.setText(currentSong.getmAlbumName());

        Button listView_btn=(Button)listItemView.findViewById(R.id.btn_ListView);
        listView_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),PlaySongActivity.class);
                activityStarter(intent);

            }

        });


        return listItemView;
    }
}
